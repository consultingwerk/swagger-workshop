The files in this folder are required to compile the WinKit Migration Utility (src/tools/winkit/winkitmtk.w).

The may not be required to compile or deploy the remainder of the application.
